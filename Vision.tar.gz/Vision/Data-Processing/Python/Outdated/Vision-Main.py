import test-inference, Communication
#uses 4 space notation
while(1):

