#! /usr/local/bin/python
import math

